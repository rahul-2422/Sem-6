K. Rahul
S20200010091

Steps to compile and run the code:

Go to folder of the respective algorithm and run these commands: 

1) All classes are already complied and the executable are present, if not present run command "javac <FileName>.java"
2) To run the algorithms run command "java <Filename>"

3 commands for the 3 algo's are :

i) java Sasaki
ii) java alternatealgorithm
iii) java OddEven

Input parameters:

1) Enter the number of Processing entities
2) Enter partial order
